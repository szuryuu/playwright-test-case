const API = 'https://notes-api.dicoding.dev/v2';

class AppBar extends HTMLElement {
  connectedCallback() {
    const t = this.getAttribute('title') || 'Notes';
    this.innerHTML = '<header style="font-weight:bold;padding:8px;background:#eee">' + t + '</header>';
  }
}
customElements.define('app-bar', AppBar);

class NoteForm extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <form id="add-form">
        <input id="title" name="title" type="text" placeholder="Judul catatan" required minlength="3">
        <textarea id="body" name="body" placeholder="Isi catatan" required></textarea>
        <button type="submit">Tambah</button>
      </form>`;
    this.querySelector('form').addEventListener('submit', (e) => {
      e.preventDefault();
      const title = this.querySelector('#title').value.trim();
      const body = this.querySelector('#body').value.trim();
      if (!title || !body) return;
      setLoading(true);
      fetch(`${API}/notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, body }),
      })
        .then((r) => { if (!r.ok) throw new Error('gagal'); return r.json(); })
        .then((d) => {
          setLoading(false);
          this.querySelector('form').reset();
          if (d && d.data) appendNote(d.data, document.getElementById('notes-list'));
        })
        .catch(() => { setLoading(false); alert('Gagal menyimpan catatan'); });
    });
  }
}
customElements.define('note-form', NoteForm);

class NoteItem extends HTMLElement {
  set data(d) {
    this._d = d;
    this.render();
  }
  connectedCallback() {
    if (this._d) this.render();
  }
  render() {
    const d = this._d || {};
    this.innerHTML = `
      <h3>${d.title || ''}</h3>
      <p>${d.body || ''}</p>
      <div class="actions">
        <button class="archive-btn" data-action="archive">Arsip</button>
        <button class="unarchive-btn" data-action="unarchive">Batal Arsip</button>
        <button class="delete-btn" data-action="delete">Hapus</button>
      </div>`;
    this.querySelector('[data-action="archive"]').onclick = () => archiveNote(d.id, false);
    this.querySelector('[data-action="unarchive"]').onclick = () => archiveNote(d.id, true);
    this.querySelector('[data-action="delete"]').onclick = () => deleteNote(d.id);
  }
}
customElements.define('note-item', NoteItem);

function setLoading(on) {
  let el = document.getElementById('loading-indicator');
  if (on) {
    if (!el) {
      el = document.createElement('div');
      el.id = 'loading-indicator';
      el.textContent = 'Loading...';
      el.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#ff0;padding:4px;text-align:center;z-index:9999';
      document.body.appendChild(el);
    }
    el.style.display = 'block';
  } else if (el) {
    el.style.display = 'none';
  }
}

async function getNotes() {
  setLoading(true);
  try {
    const r = await fetch(`${API}/notes`);
    const d = await r.json();
    return d.data || [];
  } finally {
    setLoading(false);
  }
}

async function getArchived() {
  const r = await fetch(`${API}/notes/archived`);
  const d = await r.json();
  return d.data || [];
}

async function archiveNote(id, unarchive) {
  setLoading(true);
  await fetch(`${API}/notes/${id}/${unarchive ? 'unarchive' : 'archive'}`, { method: 'POST' });
  setLoading(false);
  render();
}

async function deleteNote(id) {
  setLoading(true);
  await fetch(`${API}/notes/${id}`, { method: 'DELETE' });
  setLoading(false);
  render();
}

function appendNote(n, container) {
  const el = document.createElement('note-item');
  el.data = n;
  container.appendChild(el);
}

function render() {
  const list = document.getElementById('notes-list');
  const alist = document.getElementById('archived-list');
  list.innerHTML = '';
  alist.innerHTML = '';
  getNotes().then((notes) => notes.forEach((n) => appendNote(n, list)));
  getArchived().then((notes) => notes.forEach((n) => appendNote(n, alist)));
}

render();
